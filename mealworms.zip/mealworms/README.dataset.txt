# mealworms > 2023-06-18 5:25pm
https://universe.roboflow.com/1-e8zeo/mealworms-oxntf

Provided by a Roboflow user
License: CC BY 4.0

